import javax.swing.*;

import java.awt.event.*;



public class App13_1 extends JFrame implements ActionListener {
	/**
	 * 
	 */
	static int n,m=0; //���ڿ���
	static int  num=0;
	private static final long serialVersionUID = 1L;
	private static BankDatabase bankDatabase =new BankDatabase(); 
	static App13_1 frm =new App13_1();
	
	static JButton bt1 = new JButton("1");					//��ť����
	static JButton bt2 = new JButton("2");
	static JButton bt3 = new JButton("3");
	static JButton bt4 = new JButton("4");
	static JButton bt5 = new JButton("5");
	static JButton bt6 = new JButton("6");
	static JButton bt7 = new JButton("7");
	static JButton bt8 = new JButton("8");
	static JButton bt9 = new JButton("9");
	static JButton bt0 = new JButton("0");
	static JButton btenter = new JButton("enter");
	
	
	String name =null;
	String key =null;
	static JTextArea ta = new JTextArea("XX",5,20);
	public static void main(String[] args)
	{
		
		if(n==0){
			
		bt1.addActionListener(frm);
		bt2.addActionListener(frm);
		bt3.addActionListener(frm);
		bt4.addActionListener(frm);
		bt5.addActionListener(frm);
		bt6.addActionListener(frm);
		bt7.addActionListener(frm);
		bt8.addActionListener(frm);
		bt9.addActionListener(frm);
		bt0.addActionListener(frm);
		btenter.addActionListener(frm);
	
		
		
		frm.setLayout(null);
		int width=800;int height=600;
		frm.setSize(width, height);
		ta.setBounds(200, 60, 400, 150);   // 1 2 parameters:location, 3 4:witdth height
		ta.setText("Welcome to the ATM!\n"+"click the enter then enter your account number:");
		
		bt1.setBounds(200, 250, 100, 40);    //button1 location and size setting		
		bt2.setBounds(300, 250, 100, 40); 
		bt3.setBounds(400, 250, 100, 40); 
		bt4.setBounds(200, 290, 100, 40); 		//second line
		bt5.setBounds(300, 290, 100, 40); 
		bt6.setBounds(400, 290, 100, 40); 
		bt7.setBounds(200, 330, 100, 40); 
		bt8.setBounds(300, 330, 100, 40); 
		bt9.setBounds(400, 330, 100, 40); 
		bt0.setBounds(200, 370, 100, 40); 
		btenter.setBounds(300, 370, 200, 40); 
		
		
		
		frm.add(ta);		
		frm.add(bt1);
		frm.add(bt2);
		frm.add(bt3);
		frm.add(bt4);
		frm.add(bt5);
		frm.add(bt6);
		frm.add(bt7);
		frm.add(bt8);
		frm.add(bt9);
		frm.add(bt0);
		frm.add(btenter);
		
		
		frm.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frm.setVisible(true);
		}

		
	}
	
	
	@Override
	public void actionPerformed(ActionEvent e) {
		JButton but=(JButton)e.getSource();  //��ȡ�¼�Դ��ǿ��ת��ΪJButton����
		if(but==bt1){			//switch case (int or String )
				if(m==0){
					if(n==0)
				{
					ta.setText("click enter to go on");
				}
				else{num=num*10+1;
				ta.setText(String.valueOf(num));
				n=2;
				}}
				if(m==1){
					num=num*10+1;
					ta.setText(String.valueOf(num));
					n=3;
				}
				if(m==3)
				{
					ta.setText("your balance is......\n"+"Please click the enter to back");
					m=7;
					
				}
				if(m==4)
				{
					ta.setText("click the enter to back ");
														
				}
				if(m==6)
				{
					ta.setText("Main menu:\n"+"1 - View my balance\n"+"2 - Withdraw cash\n"+"3 - Deposit funds\n"+"4 - Exit");
					m=3;
				}
				if(m==5)
				{
					ta.setText("$20 is being ready for you!");
					m=6;
				}
			
		}
		if(but==bt2){
				if(m==0){
				if(n==0)
				{
					ta.setText("click enter to go on");
				}
				else{num=num*10+2;
				ta.setText(String.valueOf(num));
				n=2;
				}}
				if(m==1){
					num=num*10+2;
					ta.setText(String.valueOf(num));
					n=3;
				}
				if(m==5)
				{
					ta.setText("$40 is being ready for you!");
					m=6;
				}
				
				if(m==3)
				{
					ta.setText("Withdrawal Menu:\n"+"1 - $20"+ "		2 - $40\n"+"3 - $60"+"		4 - $100\n"+"5 - $200"+"		6 - Cancel transaction");
					m=5;
					
				}
				if(m==4)
				{
					ta.setText("click the enter to back ");
														
				}
				if(m==6)
				{
					ta.setText("Main menu:\n"+"1 - View my balance\n"+"2 - Withdraw cash\n"+"3 - Deposit funds\n"+"4 - Exit");
					m=3;
				}
				
			
				
			}
		if(but==bt3){
			if(m==0){
				if(n==0)
				{
					ta.setText("click enter to go on");
				}
				else{num=num*10+3;
				ta.setText(String.valueOf(num));
				n=2;
				}}
				if(m==1){
					num=num*10+3;
					ta.setText(String.valueOf(num));
					n=3;
				}

				if(m==4)
				{
					ta.setText("click the enter to back ");
														
				}
				if(m==3)
				{
					
					ta.setText("put your money in the slot\n"+"click the enter to back");
					m=4;
										
				}
				if(m==6)
				{
					ta.setText("Main menu:\n"+"1 - View my balance\n"+"2 - Withdraw cash\n"+"3 - Deposit funds\n"+"4 - Exit");
					m=3;
				}
				if(m==5)
				{
					ta.setText("$60 is being ready for you!");
					m=6;
				}
			
			}
		if(but==bt4){
			if(m==0){
				if(n==0)
				{
					ta.setText("click enter to go on");
				}
				else{num=num*10+4;
				ta.setText(String.valueOf(num));
				n=2;
				}}
				if(m==1){
					num=num*10+4;
					ta.setText(String.valueOf(num));
					n=3;
				}
				if(m==3)
				{
					ta.setText("be careful with your card!\n"+"goodbye");
					m=0;
					n=0;
				}
				if(m==4)
				{
					ta.setText("click the enter to back ");
														
				}
				if(m==6)
				{
					ta.setText("Main menu:\n"+"1 - View my balance\n"+"2 - Withdraw cash\n"+"3 - Deposit funds\n"+"4 - Exit");
					m=3;
				}
				if(m==5)
				{
					ta.setText("$100 is being ready for you!");
					m=6;
				}
				
			}
		if(but==bt5){
			if(m==0){
				if(n==0)
				{
					ta.setText("click enter to go on");
				}
				else{num=num*10+5;
				ta.setText(String.valueOf(num));
				n=2;
				}}
				if(m==1){
					num=num*10+5;
					ta.setText(String.valueOf(num));
					n=3;
				}
				if(m==3)
				{
					ta.setText("Please click 1 2 3 or 4!");
				}
				if(m==4)
				{
					ta.setText("click the enter to back ");
														
				}
				if(m==6)
				{
					ta.setText("Main menu:\n"+"1 - View my balance\n"+"2 - Withdraw cash\n"+"3 - Deposit funds\n"+"4 - Exit");
					m=3;
				}
				if(m==5)
				{
					ta.setText("$200 is being ready for you!");
					m=6;
				}
				
			}
		if(but==bt6){
			if(m==0){
				if(n==0)
				{
					ta.setText("click enter to go on");
				}
				else{
				num=num*10+6;
				ta.setText(String.valueOf(num));
				n=2;
				}}
				if(m==1){
					num=num*10+6;
					ta.setText(String.valueOf(num));
					n=3;
				}
				if(m==3)
				{
					ta.setText("Please click 1 2 3 or 4!");
				}
				if(m==4)
				{
					ta.setText("click the enter to back ");
														
				}
				if(m==6)
				{
					ta.setText("Main menu:\n"+"1 - View my balance\n"+"2 - Withdraw cash\n"+"3 - Deposit funds\n"+"4 - Exit");
					m=3;
				}
				if(m==5)
				{
					ta.setText("Main menu:\n"+"1 - View my balance\n"+"2 - Withdraw cash\n"+"3 - Deposit funds\n"+"4 - Exit");
					m=3;
				}
				
			}
		if(but==bt7){
			if(m==0){
				if(n==0)
				{
					ta.setText("click enter to go on");
				}else{
				num=num*10+7;
				ta.setText(String.valueOf(num));
				n=2;
				}}
				if(m==1){
					num=num*10+7;
					ta.setText(String.valueOf(num));
					n=3;
				}
				if(m==3)
				{
					ta.setText("Please click 1 2 3 or 4!");
				}
				if(m==4)
				{
					ta.setText("click the enter to back ");
														
				}
				if(m==6)
				{
					ta.setText("Main menu:\n"+"1 - View my balance\n"+"2 - Withdraw cash\n"+"3 - Deposit funds\n"+"4 - Exit");
					m=3;
				}
				if(m==5)
				{
					ta.setText("Please click 1 2 3 4 5 or 6");
					m=6;
				}
				
			
			}
		if(but==bt8){
			if(m==0){
				if(n==0)
				{
					ta.setText("click enter to go on");
				}
				else{
				num=num*10+8;
				ta.setText(String.valueOf(num));
				n=2;
				}}
				if(m==1){
					num=num*10+8;
					ta.setText(String.valueOf(num));
					n=3;
				}
				if(m==3)
				{
					ta.setText("Please click 1 2 3 or 4!");
				}
				if(m==4)
				{
					ta.setText("click the enter to back ");
														
				}
				if(m==6)
				{
					ta.setText("Main menu:\n"+"1 - View my balance\n"+"2 - Withdraw cash\n"+"3 - Deposit funds\n"+"4 - Exit");
					m=3;
				}
				if(m==5)
				{
					ta.setText("Please click 1 2 3 4 5 or 6");
					m=6;
				}
				
			}
		if(but==bt9){
			if(m==0){
				if(n==0)
				{
					ta.setText("click enter to go on");
				}
				else{
				num=num*10+9;
				ta.setText(String.valueOf(num));
				n=2;
				}
			}
				if(m==1){
					num=num*10+9;
					ta.setText(String.valueOf(num));
					n=3;
				}
				if(m==3)
				{
					ta.setText("Please click 1 2 3 or 4!");
				}
				if(m==4)
				{
					ta.setText("click the enter to back ");
														
				}
				if(m==6)
				{
					ta.setText("Main menu:\n"+"1 - View my balance\n"+"2 - Withdraw cash\n"+"3 - Deposit funds\n"+"4 - Exit");
					m=3;
				}
				if(m==5)
				{
					ta.setText("Please click 1 2 3 4 5 or 6");
					m=6;
				}
				
			}
		if(but==bt0){
			if(m==0){
				if(n==0)
				{
					ta.setText("click enter to go on");
				}
			num=num*10+0;
			ta.setText(String.valueOf(num));
			n=2;
			}
			if(m==1){
				num=num*10+0;
				ta.setText(String.valueOf(num));
				n=3;
			}
			if(m==3)
			{
				ta.setText("Please click 1 2 3 or 4!");
			}
			if(m==4)
			{
				ta.setText("click the enter to back ");
													
			}
			if(m==6)
			{
				ta.setText("Main menu:\n"+"1 - View my balance\n"+"2 - Withdraw cash\n"+"3 - Deposit funds\n"+"4 - Exit");
				m=3;
			}
			if(m==5)
			{
				ta.setText("Please click 1 2 3 4 5 or 6");
				m=6;
			}
			
		}
		if(but==btenter){
			if(n==0)
			{
				ta.setText("Please enter your account number:");
				n=1;
			}
			if(n==2){
				name=ta.getText();	
			num=0;
			ta.setText("Enter your PIN:");
			m=1;
			}
			if(n==3)
			{
				num=0;
				key=ta.getText();
				if(bankDatabase.authenticateUser(Integer.valueOf(name),Integer.valueOf(key)))
				{
					m=2;
				}
				if(m==2)
				{
					ta.setText("Main menu:\n"+"1 - View my balance\n"+"2 - Withdraw cash\n"+"3 - Deposit funds\n"+"4 - Exit");
					m=3;
					n=4;
				}
				else
				{
					ta.setText("your number or PIN is wrong!");					
					n=0;
					m=0;
						}
					}
			if(n==4)
			{
				if(m==3||m==4||m==6||m==7)
				{
					ta.setText("Main menu:\n"+"1 - View my balance\n"+"2 - Withdraw cash\n"+"3 - Deposit funds\n"+"4 - Exit");
					m=3;
				}
			}
		}
		
		
	}
		
	
}